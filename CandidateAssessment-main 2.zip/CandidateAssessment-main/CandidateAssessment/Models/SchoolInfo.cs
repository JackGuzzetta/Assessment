using System;
using System.Collections.Generic;

namespace CandidateAssessment.Models
{
    public partial class SchoolInfo
    {
        public SchoolInfo()
        {
            Students = new HashSet<Student>();
        }

        public int SchoolId { get; set; }
        public string? Name { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }

        public virtual ICollection<Student> Students { get; set; }
    }
}
