﻿using CandidateAssessment.Models;
using CandidateAssessment.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;

namespace CandidateAssessment.Controllers
{
    public class RecordsController : Controller
    {
        private StudentService _studentService;
        private SchoolService _schoolService;
        
        public RecordsController(StudentService studentService, SchoolService schoolService)
        {
            _studentService = studentService;
            _schoolService = schoolService;
        }

        public IActionResult Students()
        {
            ViewBag.AgeList = CreateAgeList();
            ViewBag.SchoolList = CreateSchoolDropdownList();
            ViewBag.OrgList = CreateStudentOrgDropdown();

            var model = _studentService.GetStudents().OrderBy(s => s.LastName);
            return View(model);
        }

        public IActionResult Schools()
        {
            var model = _schoolService.GetSchools().OrderBy(s => s.Name);
            return View(model);
        }

        public IActionResult SchoolInfo()
        {
            ViewBag.AgeList = CreateAgeList();
            ViewBag.SchoolList = CreateSchoolDropdownList();
            ViewBag.OrgList = CreateStudentOrgDropdown();

            var model = _studentService.GetStudents().OrderBy(s => s.LastName);
            return View(model);          
        }

        [HttpPost]
        public IActionResult SaveStudent(Student model)
        {
            var student = _studentService;
            student.AddStudents(model);
            return RedirectToAction("Students");
        }

        private List<SelectListItem> CreateAgeList()
        {
            var ageList = new List<SelectListItem>();
            for (int i = 18; i < 100; i++)
            {
                ageList.Add(new SelectListItem
                {
                    Text = i.ToString(),
                    Value = i.ToString()
                });
            }
            return ageList;
        }
        private List<SelectListItem> CreateSchoolDropdownList()
        {
            // replace this code with code to grab the schools and create a List<SelectListItem> object from them.
            var schools = _schoolService.GetSchools();
            var schoolList = schools.Select(s => new SelectListItem
            {
                Value = s.SchoolId.ToString(),
                Text = s.Name
            }).ToList();
            return schoolList;
        }
        public List<SelectListItem> CreateStudentOrgDropdown(){
            var studentOrgs = _studentService.GetStudents()
                .SelectMany(s => s.OrgAssignments)
                .Select(oa => oa.StudentOrg)
                .Distinct()
                .ToList();
            var orgList = studentOrgs.Select(s => new SelectListItem
            {
                Value = s.Id.ToString(),
                Text = s.OrgName
            }).ToList();
            return orgList;
        }
    }
}